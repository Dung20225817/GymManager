--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.3
-- Dumped by pg_dump version 16.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE itssprj_ver1;
--
-- Name: itssprj_ver1; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE itssprj_ver1 WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Vietnamese_Vietnam.1258';


ALTER DATABASE itssprj_ver1 OWNER TO postgres;

\connect itssprj_ver1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer (
    age integer,
    id integer NOT NULL,
    userid integer NOT NULL,
    update_at timestamp(6) without time zone,
    email character varying(255),
    firstname character varying(255),
    gender character varying(255),
    lastname character varying(255),
    phone character varying(255)
);


ALTER TABLE public.customer OWNER TO postgres;

--
-- Name: customer_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customer_seq
    START WITH 1
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.customer_seq OWNER TO postgres;

--
-- Name: exercise_session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.exercise_session (
    customerid integer,
    id integer NOT NULL,
    trainerid integer,
    begin_at timestamp(6) without time zone,
    end_at timestamp(6) without time zone,
    description character varying(255),
    exercise_type character varying(255)
);


ALTER TABLE public.exercise_session OWNER TO postgres;

--
-- Name: exercise_session_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.exercise_session_seq
    START WITH 1
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.exercise_session_seq OWNER TO postgres;

--
-- Name: member_register; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.member_register (
    begin_at date,
    create_at date NOT NULL,
    end_at date,
    id integer NOT NULL,
    memberid integer NOT NULL,
    membershipid integer NOT NULL,
    status character varying(255) NOT NULL
);


ALTER TABLE public.member_register OWNER TO postgres;

--
-- Name: member_register_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.member_register_seq
    START WITH 1
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.member_register_seq OWNER TO postgres;

--
-- Name: membership; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.membership (
    id integer NOT NULL,
    price real NOT NULL,
    description character varying(255),
    exercise_type character varying(255) NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.membership OWNER TO postgres;

--
-- Name: membership_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.membership_seq
    START WITH 1
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.membership_seq OWNER TO postgres;

--
-- Name: payment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payment (
    amount real NOT NULL,
    create_at date NOT NULL,
    customerid integer NOT NULL,
    id integer NOT NULL,
    paid boolean NOT NULL,
    method character varying(255) NOT NULL
);


ALTER TABLE public.payment OWNER TO postgres;

--
-- Name: payment_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.payment_seq
    START WITH 1
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payment_seq OWNER TO postgres;

--
-- Name: review; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.review (
    create_at date NOT NULL,
    customerid integer NOT NULL,
    id integer NOT NULL,
    text character varying(255) NOT NULL
);


ALTER TABLE public.review OWNER TO postgres;

--
-- Name: review_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.review_seq
    START WITH 1
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.review_seq OWNER TO postgres;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    roleid integer NOT NULL,
    rolename character varying(255) NOT NULL
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- Name: roles_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.roles_seq
    START WITH 1
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.roles_seq OWNER TO postgres;

--
-- Name: room; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.room (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    status character varying(255) NOT NULL
);


ALTER TABLE public.room OWNER TO postgres;

--
-- Name: room_equipment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.room_equipment (
    id integer NOT NULL,
    quantity integer NOT NULL,
    roomid integer NOT NULL,
    equipment_name character varying(255) NOT NULL,
    status character varying(255) NOT NULL
);


ALTER TABLE public.room_equipment OWNER TO postgres;

--
-- Name: room_equipment_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.room_equipment_seq
    START WITH 1
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.room_equipment_seq OWNER TO postgres;

--
-- Name: room_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.room_seq
    START WITH 1
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.room_seq OWNER TO postgres;

--
-- Name: staff; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.staff (
    age integer,
    id integer NOT NULL,
    userid integer NOT NULL,
    email character varying(255),
    firstname character varying(255),
    gender character varying(255),
    lastname character varying(255),
    phone character varying(255),
    rank character varying(255)
);


ALTER TABLE public.staff OWNER TO postgres;

--
-- Name: staff_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.staff_seq
    START WITH 1
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.staff_seq OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    roleid integer NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    password character varying(255) NOT NULL,
    username character varying(255) NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_seq
    START WITH 1
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_seq OWNER TO postgres;

--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer (age, id, userid, update_at, email, firstname, gender, lastname, phone) FROM stdin;
\.
COPY public.customer (age, id, userid, update_at, email, firstname, gender, lastname, phone) FROM '$$PATH$$/4930.dat';

--
-- Data for Name: exercise_session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.exercise_session (customerid, id, trainerid, begin_at, end_at, description, exercise_type) FROM stdin;
\.
COPY public.exercise_session (customerid, id, trainerid, begin_at, end_at, description, exercise_type) FROM '$$PATH$$/4931.dat';

--
-- Data for Name: member_register; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.member_register (begin_at, create_at, end_at, id, memberid, membershipid, status) FROM stdin;
\.
COPY public.member_register (begin_at, create_at, end_at, id, memberid, membershipid, status) FROM '$$PATH$$/4932.dat';

--
-- Data for Name: membership; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.membership (id, price, description, exercise_type, name) FROM stdin;
\.
COPY public.membership (id, price, description, exercise_type, name) FROM '$$PATH$$/4933.dat';

--
-- Data for Name: payment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payment (amount, create_at, customerid, id, paid, method) FROM stdin;
\.
COPY public.payment (amount, create_at, customerid, id, paid, method) FROM '$$PATH$$/4934.dat';

--
-- Data for Name: review; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.review (create_at, customerid, id, text) FROM stdin;
\.
COPY public.review (create_at, customerid, id, text) FROM '$$PATH$$/4935.dat';

--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roles (roleid, rolename) FROM stdin;
\.
COPY public.roles (roleid, rolename) FROM '$$PATH$$/4936.dat';

--
-- Data for Name: room; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.room (id, name, status) FROM stdin;
\.
COPY public.room (id, name, status) FROM '$$PATH$$/4937.dat';

--
-- Data for Name: room_equipment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.room_equipment (id, quantity, roomid, equipment_name, status) FROM stdin;
\.
COPY public.room_equipment (id, quantity, roomid, equipment_name, status) FROM '$$PATH$$/4938.dat';

--
-- Data for Name: staff; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.staff (age, id, userid, email, firstname, gender, lastname, phone, rank) FROM stdin;
\.
COPY public.staff (age, id, userid, email, firstname, gender, lastname, phone, rank) FROM '$$PATH$$/4939.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, roleid, created_at, password, username) FROM stdin;
\.
COPY public.users (id, roleid, created_at, password, username) FROM '$$PATH$$/4940.dat';

--
-- Name: customer_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customer_seq', 101, true);


--
-- Name: exercise_session_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.exercise_session_seq', 201, true);


--
-- Name: member_register_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.member_register_seq', 51, true);


--
-- Name: membership_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.membership_seq', 1, false);


--
-- Name: payment_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payment_seq', 51, true);


--
-- Name: review_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.review_seq', 1, false);


--
-- Name: roles_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.roles_seq', 1, false);


--
-- Name: room_equipment_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.room_equipment_seq', 201, true);


--
-- Name: room_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.room_seq', 1, false);


--
-- Name: staff_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.staff_seq', 1, false);


--
-- Name: users_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_seq', 151, true);


--
-- Name: customer customer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_pkey PRIMARY KEY (id);


--
-- Name: customer customer_userid_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_userid_key UNIQUE (userid);


--
-- Name: exercise_session exercise_session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exercise_session
    ADD CONSTRAINT exercise_session_pkey PRIMARY KEY (id);


--
-- Name: member_register member_register_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.member_register
    ADD CONSTRAINT member_register_pkey PRIMARY KEY (id);


--
-- Name: membership membership_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.membership
    ADD CONSTRAINT membership_pkey PRIMARY KEY (id);


--
-- Name: payment payment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment
    ADD CONSTRAINT payment_pkey PRIMARY KEY (id);


--
-- Name: review review_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review
    ADD CONSTRAINT review_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (roleid);


--
-- Name: room_equipment room_equipment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.room_equipment
    ADD CONSTRAINT room_equipment_pkey PRIMARY KEY (id);


--
-- Name: room room_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.room
    ADD CONSTRAINT room_pkey PRIMARY KEY (id);


--
-- Name: staff staff_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT staff_pkey PRIMARY KEY (id);


--
-- Name: staff staff_userid_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT staff_userid_key UNIQUE (userid);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: member_register fk44s4pmf8vd7mbtvm8ijx8q8ww; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.member_register
    ADD CONSTRAINT fk44s4pmf8vd7mbtvm8ijx8q8ww FOREIGN KEY (membershipid) REFERENCES public.membership(id);


--
-- Name: room_equipment fk6dv4jm7h06o1mqbo3d4scpnl5; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.room_equipment
    ADD CONSTRAINT fk6dv4jm7h06o1mqbo3d4scpnl5 FOREIGN KEY (roomid) REFERENCES public.room(id);


--
-- Name: payment fk9hbr526akmymjp0i5t8xwdxqt; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment
    ADD CONSTRAINT fk9hbr526akmymjp0i5t8xwdxqt FOREIGN KEY (customerid) REFERENCES public.customer(id);


--
-- Name: member_register fkav3tqm8lnh57jq21mhn4gfepy; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.member_register
    ADD CONSTRAINT fkav3tqm8lnh57jq21mhn4gfepy FOREIGN KEY (memberid) REFERENCES public.customer(id);


--
-- Name: staff fkgo9aw233eealotko2bee8c4r6; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT fkgo9aw233eealotko2bee8c4r6 FOREIGN KEY (userid) REFERENCES public.users(id);


--
-- Name: users fkgrhs0suhl8cbodxn47xadxp94; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fkgrhs0suhl8cbodxn47xadxp94 FOREIGN KEY (roleid) REFERENCES public.roles(roleid);


--
-- Name: customer fkm6c7m2yovk9ppw34vo8huj79n; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT fkm6c7m2yovk9ppw34vo8huj79n FOREIGN KEY (userid) REFERENCES public.users(id);


--
-- Name: exercise_session fkntauqw4veto158ptiim70vt5d; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exercise_session
    ADD CONSTRAINT fkntauqw4veto158ptiim70vt5d FOREIGN KEY (trainerid) REFERENCES public.staff(id);


--
-- Name: review fkry6hyp71d3k629ky7rgl2lnxk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review
    ADD CONSTRAINT fkry6hyp71d3k629ky7rgl2lnxk FOREIGN KEY (customerid) REFERENCES public.customer(id);


--
-- Name: exercise_session fksn2ek0lcmho9sk6133se9wb1x; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exercise_session
    ADD CONSTRAINT fksn2ek0lcmho9sk6133se9wb1x FOREIGN KEY (customerid) REFERENCES public.customer(id);


--
-- PostgreSQL database dump complete
--

